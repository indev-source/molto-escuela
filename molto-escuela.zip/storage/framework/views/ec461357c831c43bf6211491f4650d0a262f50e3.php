<?php $__env->startSection('title','Inicio'); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\trabajo\inusual\escuela\molto-escuela\resources\views/school/index.blade.php ENDPATH**/ ?>