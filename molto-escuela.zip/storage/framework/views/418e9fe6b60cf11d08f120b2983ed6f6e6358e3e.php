<div class="row">
    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('name','Nombre'); ?>

            <?php echo Form::text('name',$campus->name,['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('clave_sep','Clave SEP'); ?>

            <?php echo Form::text('clave_sep',$campus->clave_sep,['class'=>'form-control']); ?>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <?php echo Form::label('clave_plantel','Clave del plantel'); ?>

        <?php echo Form::text('clave_plantel',$campus->clave_plantel,['class'=>'form-control']); ?>

    </div>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <?php echo Form::label('phone_office','Telefono de la oficina'); ?>

        <?php echo Form::text('phone_office',$campus->phone_office,['class'=>'form-control']); ?>

    </div>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <?php echo Form::label('mobile_phone','Telefono celular'); ?>

        <?php echo Form::text('mobile_phone',$campus->mobile_phone,['class'=>'form-control']); ?>

    </div>
</div>
<?php /**PATH D:\trabajo\inusual\escuela\molto-escuela\resources\views/school/campus/form-create.blade.php ENDPATH**/ ?>