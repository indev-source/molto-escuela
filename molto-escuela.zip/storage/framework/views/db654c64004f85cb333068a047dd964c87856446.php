<div class="row">
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('colony','Colonia'); ?>

            <?php echo Form::text('colony',$address->colony,['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('postal_code','Codigo Postal'); ?>

            <?php echo Form::text('postal_code',$address->postal_code,['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('city','Ciudad'); ?>

            <?php echo Form::text('city',$address->city,['class'=>'form-control']); ?>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('state','Estado'); ?>

            <?php echo Form::text('state',$address->state,['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('country','Pais'); ?>

            <?php echo Form::text('country',$address->country,['class'=>'form-control']); ?>

        </div>
    </div>
</div>

<div class="form-group">
    <?php echo Form::label('address','Direccion'); ?>

    <?php echo Form::textarea('address',$address->address,['class'=>'form-control']); ?>

</div>
<?php /**PATH D:\trabajo\inusual\escuela\molto-escuela\resources\views/school/address/form-edit.blade.php ENDPATH**/ ?>