<div class="row">
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('name','Nombre(s)'); ?>

            <?php echo Form::text('name','',['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('lastname','Apellido Paterno'); ?>

            <?php echo Form::text('lastname','',['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('mothers_lastname','Apellido Materno'); ?>

            <?php echo Form::text('mothers_lastname','',['class'=>'form-control']); ?>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('birthday','Fecha de nacimiento'); ?>

            <?php echo Form::date('birthday','',['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('curp','CURP'); ?>

            <?php echo Form::text('curp','',['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('rfc','RFC'); ?>

            <?php echo Form::text('rfc','',['class'=>'form-control']); ?>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('campus_id','Plantel'); ?>

            <?php echo Form::select('campus_id',$campus,'',['class'=>'form-control','placeholder'=>'Selecciona un plantel disponible']); ?>

        </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('phone_office','Telefono de la oficina'); ?>

            <?php echo Form::text('phone_office','',['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('mobile_phone','Telefono celular'); ?>

            <?php echo Form::text('mobile_phone','',['class'=>'form-control']); ?>

        </div>
    </div>
</div>
<?php /**PATH D:\trabajo\inusual\escuela\molto-escuela\resources\views/school/peoples/form-create.blade.php ENDPATH**/ ?>