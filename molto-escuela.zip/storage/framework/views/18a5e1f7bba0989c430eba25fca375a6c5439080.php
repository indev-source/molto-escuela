<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <?php echo Form::label('email','Email'); ?>

        <?php echo Form::email('email',$employee->people->user->email,['class'=>'form-control']); ?>

    </div>
</div>
<?php /**PATH D:\trabajo\inusual\escuela\molto-escuela\resources\views/school/credentials/form-edit.blade.php ENDPATH**/ ?>