<div class="row">
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <?php echo Form::label('email','Email'); ?>

        <?php echo Form::email('email','',['class'=>'form-control']); ?>

    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <?php echo Form::label('password','Contraseña'); ?>

        <?php echo Form::password('password',['class'=>'form-control']); ?>

    </div>
</div>
<?php /**PATH D:\trabajo\inusual\escuela\molto-escuela\resources\views/school/credentials/form-create.blade.php ENDPATH**/ ?>