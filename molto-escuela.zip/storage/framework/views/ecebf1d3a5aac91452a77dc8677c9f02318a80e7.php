<footer class="footer text-center text-muted">
    All Rights Reserved by Adminmart. Designed and Developed by <a
        href="https://wrappixel.com">WrapPixel</a>.
</footer>
<?php /**PATH D:\trabajo\inusual\escuela\molto-escuela\resources\views/layouts/shared/footer.blade.php ENDPATH**/ ?>